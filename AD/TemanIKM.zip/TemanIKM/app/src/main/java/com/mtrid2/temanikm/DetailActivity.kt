package com.mtrid2.temanikm

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.mtrid2.temanikm.databinding.ActivityDetailBinding
import com.mtrid2.temanikm.ui.OrderInfo

class DetailActivity : AppCompatActivity() {
    private var order: OrderInfo? = null
    private var position: Int = 0

    private lateinit var btnUpdate: Button
    private lateinit var binding: ActivityDetailBinding

    companion object {
        const val EXTRA_ORDER = "extra_order"
        const val EXTRA_POSITION = "extra_position"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        order = intent.getParcelableExtra(EXTRA_ORDER)
        position = intent.getIntExtra(EXTRA_POSITION, 0)

        //nampilin detail Order Info

        supportActionBar?.title = "Detail Order Information"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        //kalo bisa buat session biar gampang
        val user = "Admin"
        if (user == "Admin"){
            binding.btnUpdate.visibility = View.VISIBLE
            binding.btnFinish.visibility = View.GONE
            binding.btnJoin.visibility = View.GONE
        } else if (user == "Employee"){
            binding.btnUpdate.visibility = View.GONE
            binding.btnFinish.visibility = View.VISIBLE
            binding.btnJoin.visibility = View.VISIBLE
        }
    }

    fun onClick(v: View){
        if (v.id == R.id.btn_update) {
            val intent = Intent(this@DetailActivity, AddUpdateItemActivity::class.java)
            intent.putExtra(AddUpdateItemActivity.EXTRA_POSITION, position)
            intent.putExtra(AddUpdateItemActivity.EXTRA_ORDER, order)
            startActivity(intent)
        } else if (v.id == R.id.btn_finish) {
            binding.status.text = "SELESAI"
            //di db update ke selesai
        } else if (v.id == R.id.btn_join) {
            val banyak = binding.banyakKaryawan.text.toString().trim()
            binding.banyakKaryawan.text = (Integer.parseInt(banyak) + 1).toString()
            //update db banyak karyawan
        }
    }
}