package com.mtrid2.temanikm

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    private lateinit var edtUsername: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnLogin: ImageView
    private lateinit var tvSignup: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtUsername = findViewById(R.id.edt_username)
        edtPassword = findViewById(R.id.edt_password)
        btnLogin = findViewById(R.id.arrow)
        tvSignup = findViewById(R.id.tv_signup)

        //btnLogin.setOnClickListener(this)
    }

    fun onClick (v: View) {
        when (v.id) {

            R.id.arrow -> {
                val inputUsername = edtUsername.text.toString().trim()
                val inputPass = edtPassword.text.toString().trim()

                var isEmptyFields = false

                if (inputUsername.isEmpty()) {
                    isEmptyFields = true
                    edtUsername.error = "Field ini tidak boleh kosong"
                }
                if (inputPass.isEmpty()) {
                    isEmptyFields = true
                    edtPassword.error = "Field ini tidak boleh kosong"
                }

                if (!isEmptyFields) {
                    // cek username password ke db
                    val match = true
                    if (match) {
                        val user = "Admin" // ambil data dari db, ini jenis usernya admin/employee, kalo bisa jadikan session
                        val moveWithDataIntent =
                            Intent(this@MainActivity, MainActivity2::class.java)
                        moveWithDataIntent.putExtra(MainActivity2.EXTRA_NAME, inputUsername)
                        moveWithDataIntent.putExtra(MainActivity2.EXTRA_USER, user)
                        startActivity(moveWithDataIntent)
                    }
                }
            }

            R.id.tv_signup -> {
                val moveIntent = Intent(this@MainActivity, RegisterActivity::class.java)
                startActivity(moveIntent)
            }
        }
    }
}

