package com.mtrid2.temanikm

import android.content.ContentValues
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import com.mtrid2.temanikm.databinding.ActivityAddUpdateItemBinding
import com.mtrid2.temanikm.ui.OrderInfo

class AddUpdateItemActivity : AppCompatActivity(), View.OnClickListener, AdapterView.OnItemSelectedListener {
    private var spinner: Spinner? = null
    private var arrayAdapter: ArrayAdapter<String>? = null

    private var isEdit = false
    private var order: OrderInfo? = null
    private var position: Int = 0
    private var items: String = ""

    //nama barang
    private var itemList = arrayOf(
            "Lemari",
            "Pintu",
            "Meja",
            "Kursi"
    )

    private lateinit var binding: ActivityAddUpdateItemBinding

    companion object {
        const val EXTRA_ORDER = "extra_order"
        const val EXTRA_POSITION = "extra_position"
        const val REQUEST_ADD = 100
        const val RESULT_ADD = 101
        const val REQUEST_UPDATE = 200
        const val RESULT_UPDATE = 201
        const val RESULT_DELETE = 301
        const val ALERT_DIALOG_CLOSE = 10
        const val ALERT_DIALOG_DELETE = 20
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddUpdateItemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        spinner = findViewById(R.id.spinners)
        arrayAdapter = ArrayAdapter(applicationContext, R.layout.spinner_item, itemList)
        spinner?.adapter = arrayAdapter
        spinner?.setSelection(0)
        spinner?.onItemSelectedListener = this

        order = intent.getParcelableExtra(EXTRA_ORDER)
        if (order != null) {
            position = intent.getIntExtra(EXTRA_POSITION, 0)
            isEdit = true
        } else {
            order = OrderInfo()
        }

        val actionBarTitle: String
        if (isEdit) {
            actionBarTitle = "Ubah"
            order?.let {
                binding.spinners.setSelection(itemList.indexOf(it.namaBarang))
                binding.edtDescription.setText(it.description)
                it.banyak?.let { it1 -> binding.edtBanyak.setText(it1) }
            }
        } else {
            actionBarTitle = "Tambah"
        }
        supportActionBar?.title = actionBarTitle
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        if (isEdit){
            menuInflater.inflate(R.menu.menu_form, menu)
            return super.onCreateOptionsMenu(menu)
        } else{
            return true
        }

    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            //DELETE ITEM
            R.id.action_delete -> showAlertDialog(ALERT_DIALOG_DELETE)
            android.R.id.home -> showAlertDialog(ALERT_DIALOG_CLOSE)
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        showAlertDialog(ALERT_DIALOG_CLOSE)
    }

    override fun onClick(v: View?) {
        if (v?.id == R.id.btn_submit) {
            val namaBarang = items.trim()
            val description = binding.edtDescription.text.toString().trim()
            val banyak_barang = binding.edtBanyak.text.toString().trim()

            if (banyak_barang.isEmpty()) {
                binding.edtBanyak.error = "Field can not be blank"
                return
            }
            order?.namaBarang = namaBarang
            order?.description = description
            order?.banyak = banyak_barang.toInt()
            val moveIntent = Intent(this@AddUpdateItemActivity, MainActivity2::class.java)

            //val values = ContentValues()
            //sambung db
            /*values.put(DatabaseContract.NoteColumns.TITLE, title)
            values.put(DatabaseContract.NoteColumns.DESCRIPTION, description)*/
            if (isEdit) {
                //update data db
                /*val result = noteHelper.update(note?.id.toString(), values).toLong()
                if (result > 0) {
                    setResult(RESULT_UPDATE, intent)
                    finish()
                } else {
                    Toast.makeText(this@NoteAddUpdateActivity, "Gagal mengupdate data", Toast.LENGTH_SHORT).show()
                }*/
                startActivity(moveIntent)
            } else {
                //insert data db
                    /*
                val result = noteHelper.insert(values)
                if (result > 0) {
                    note?.id = result.toInt()
                    setResult(RESULT_ADD, intent)
                    finish()
                } else {
                    Toast.makeText(this@NoteAddUpdateActivity, "Gagal menambah data", Toast.LENGTH_SHORT).show()
                }*/
                startActivity(moveIntent)
            }
        }
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        items = parent?.getItemAtPosition(position) as String
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
    }

    private fun showAlertDialog(type: Int) {
        val isDialogClose = type == ALERT_DIALOG_CLOSE
        val dialogTitle: String
        val dialogMessage: String
        if (isDialogClose) {
            dialogTitle = "Batal"
            dialogMessage = "Apakah anda ingin membatalkan perubahan pada form?"
        } else {
            dialogMessage = "Apakah anda yakin ingin menghapus item ini?"
            dialogTitle = "Hapus Note"
        }
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle(dialogTitle)
        alertDialogBuilder
            .setMessage(dialogMessage)
            .setCancelable(false)
            .setPositiveButton("Ya") { _, _ ->
                if (isDialogClose) {
                    finish()
                } else {
                    //delete item
                    /*val result = noteHelper.deleteById(note?.id.toString()).toLong()
                    if (result > 0) {
                        val intent = Intent()
                        intent.putExtra(EXTRA_POSITION, position)
                        setResult(RESULT_DELETE, intent)
                        finish()
                    } else {
                        Toast.makeText(this@NoteAddUpdateActivity, "Gagal menghapus data", Toast.LENGTH_SHORT).show()
                    }*/
                }
            }
            .setNegativeButton("Tidak") { dialog, _ -> dialog.cancel() }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }
}