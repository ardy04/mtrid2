package com.mtrid2.temanikm.ui

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class OrderInfo (
    var id: Int = 0,
    var namaBarang: String? = null,
    var description: String? = null,
    var banyak: Int? = null,
    var jumlahPegawai: Int? = null,
    var status: String? = null
) :Parcelable