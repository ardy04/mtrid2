@file:Suppress("DEPRECATION")

package com.mtrid2.temanikm.ui.dashboard

import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.mtrid2.temanikm.R
import com.mtrid2.temanikm.databinding.FragmentWeekBinding

class WeekFragment : Fragment() {
    private lateinit var binding: FragmentWeekBinding

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentWeekBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.txtChart1.text = "Line Chart Juni"
        setLineChartData()

        binding.txtChart2.text = "Pie Chart Juni"
        setPieChartData()
    }

    fun setLineChartData() {
        val xvalue = ArrayList<String>()
        xvalue.add("Minggu 1")
        xvalue.add("Minggu 2")
        xvalue.add("Minggu 3")
        xvalue.add("Minggu 4")

        val lineEntry = ArrayList<Entry>()
        lineEntry.add(Entry(20f, 0))
        lineEntry.add(Entry(30f, 1))
        lineEntry.add(Entry(10f, 2))
        lineEntry.add(Entry(40f, 3))

        val lineEntry1 = ArrayList<Entry>()
        lineEntry1.add(Entry(40f, 0))
        lineEntry1.add(Entry(20f, 1))
        lineEntry1.add(Entry(50f, 2))
        lineEntry1.add(Entry(10f, 3))

        val lineDataset = LineDataSet(lineEntry, "Meja")
        lineDataset.color = resources.getColor(R.color.prime)
        lineDataset.circleRadius = 0f

        val lineDataset1 = LineDataSet(lineEntry1, "Kursi")
        lineDataset1.color = resources.getColor(R.color.purple_500)
        lineDataset1.circleRadius = 0f

        val finalDataset = ArrayList<LineDataSet>()
        finalDataset.add(lineDataset)
        finalDataset.add(lineDataset1)

        val data = LineData(xvalue, finalDataset as List<ILineDataSet>?)

        binding.lineChart.data = data
        binding.lineChart.setBackgroundColor(resources.getColor(R.color.white))
        binding.lineChart.animateXY(3000,3000)
    }

    fun setPieChartData(){
        val xvalues = ArrayList<String>()
        xvalues.add("Meja")
        xvalues.add("Kursi")
        xvalues.add("Pintu")
        xvalues.add("Lemari")

        val pieChartEntry = ArrayList<Entry>()
        pieChartEntry.add(Entry(25f, 0))
        pieChartEntry.add(Entry(45f, 1))
        pieChartEntry.add(Entry(30f, 2))
        pieChartEntry.add(Entry(10f, 3))

        val colors = ArrayList<Int>()
        colors.add(Color.CYAN)
        colors.add(Color.GREEN)
        colors.add(Color.YELLOW)
        colors.add(Color.MAGENTA)

        val pieDataset = PieDataSet(pieChartEntry, "Produksi")
        pieDataset.colors = colors
        pieDataset.sliceSpace = 5f

        val data = PieData(xvalues, pieDataset)
        binding.pieChart.data = data
        binding.pieChart.holeRadius = 15f
        binding.pieChart.setBackgroundColor(resources.getColor(R.color.white))
        binding.pieChart.animateY(3000)
        binding.pieChart.setDescription("Produksi Bulan Juni")


        val legend: Legend = binding.pieChart.legend
        legend.position = Legend.LegendPosition.RIGHT_OF_CHART_CENTER



    }
}