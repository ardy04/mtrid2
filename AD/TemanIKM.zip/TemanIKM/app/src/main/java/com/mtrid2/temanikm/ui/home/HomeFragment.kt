package com.mtrid2.temanikm.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.mtrid2.temanikm.AddUpdateItemActivity
import com.mtrid2.temanikm.databinding.ActivityOrderInfoBinding

class HomeFragment : Fragment() {

    private lateinit var adapter: OrderAdapter

    private lateinit var binding: ActivityOrderInfoBinding

    private lateinit var homeViewModel: HomeViewModel

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        binding = ActivityOrderInfoBinding.inflate(layoutInflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)

            val orderAdapter = OrderAdapter()

            binding.progressbar.visibility = View.VISIBLE

            binding.rvOrders.layoutManager = LinearLayoutManager(context)
            binding.rvOrders.setHasFixedSize(true)
            binding.rvOrders.adapter = orderAdapter

            val user = "Admin" //session
            if (user == "Admin") {
                binding.fabAdd.visibility = View.VISIBLE
                binding.fabAdd.setOnClickListener {
                    val intent = Intent(activity, AddUpdateItemActivity::class.java)
                    startActivity(intent)
                }
            } else if (user == "Employee"){
                binding.fabAdd.visibility = View.GONE
            }
        }
    }

}