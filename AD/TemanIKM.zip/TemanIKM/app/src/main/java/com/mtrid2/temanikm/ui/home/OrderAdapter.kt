package com.mtrid2.temanikm.ui.home

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mtrid2.temanikm.CustomOnItemClickListener
import com.mtrid2.temanikm.DetailActivity
import com.mtrid2.temanikm.databinding.ItemRowBinding
import com.mtrid2.temanikm.ui.OrderInfo

class OrderAdapter: RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {
    var listOrders = ArrayList<OrderInfo>()

    fun setOrder(orders: List<OrderInfo>?) {
        if (orders == null) return
        this.listOrders.clear()
        this.listOrders.addAll(orders)
    }

    fun addItem(order: OrderInfo) {
        this.listOrders.add(order)
        notifyItemInserted(this.listOrders.size - 1)
    }

    fun updateItem(position: Int, order: OrderInfo) {
        this.listOrders[position] = order
        notifyItemChanged(position, order)
    }

    fun removeItem(position: Int) {
        this.listOrders.removeAt(position)
        notifyItemRemoved(position)
        notifyItemRangeChanged(position, this.listOrders.size)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        holder.bind(listOrders[position])
    }

    override fun getItemCount(): Int = this.listOrders.size

    inner class OrderViewHolder(private val binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(Order: OrderInfo) {
            binding.tvNamaBarang.text = Order.namaBarang
            binding.tvItemStatus.text = Order.status
            binding.tvDescription.text = Order.description

            itemView.setOnClickListener(CustomOnItemClickListener(adapterPosition, object : CustomOnItemClickListener.OnItemClickCallback {
                override fun onItemClicked(view: View, position: Int) {
                    val intent = Intent(itemView.context, DetailActivity::class.java)
                    intent.putExtra(DetailActivity.EXTRA_POSITION, position)
                    intent.putExtra(DetailActivity.EXTRA_ORDER, Order)
                    itemView.context.startActivity(intent)
                }
            }))
        }
    }
} 