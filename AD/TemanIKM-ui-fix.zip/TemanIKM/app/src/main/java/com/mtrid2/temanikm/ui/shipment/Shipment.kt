package com.mtrid2.temanikm.ui.shipment

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Shipment (
    var orderID: String = "",
    var detail: Int = 0,
    var shipmentDate: String? = null,
    var finishDate: String? = null
): Parcelable