package com.mtrid2.temanikm.ui.home

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mtrid2.temanikm.ui.detail.DetailActivity
import com.mtrid2.temanikm.databinding.ItemRowBinding
import com.mtrid2.temanikm.ui.OrderInfo

class OrderAdapter: RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {
    var listOrders = ArrayList<OrderInfo>()

    fun setOrder(orders: List<OrderInfo>?) {
        if (orders == null) return
        this.listOrders.clear()
        this.listOrders.addAll(orders)
    }

    fun addItem(order: OrderInfo) {
        this.listOrders.add(order)
        notifyItemInserted(this.listOrders.size - 1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val binding = ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return OrderViewHolder(binding)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        holder.bind(listOrders[position])
    }

    override fun getItemCount(): Int = this.listOrders.size

    inner class OrderViewHolder(private val binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(Order: OrderInfo) {
            if (Order.status == "BELUM"){
                binding.tvItemStatus.setTextColor(Color.RED)
            } else {
                binding.tvItemStatus.setTextColor(Color.GREEN)
            }
            binding.tvItemStatus.text = Order.status
            binding.tvOrderType.text = Order.orderType
            binding.tvDescription.text = "Detail Divan : ${Order.detailDivan}"
            binding.tvDeadline.text = "Deadline : ${Order.deadline}"

            itemView.setOnClickListener {
                val intent = Intent(itemView.context, DetailActivity::class.java)
                intent.putExtra(DetailActivity.EXTRA_ID, Order.id)
                intent.putExtra(DetailActivity.EXTRA_ORDER, Order)
                itemView.context.startActivity(intent)
            }
        }
    }
} 