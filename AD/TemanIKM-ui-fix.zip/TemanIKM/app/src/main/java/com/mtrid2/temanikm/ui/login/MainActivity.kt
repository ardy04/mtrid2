package com.mtrid2.temanikm.ui.login

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.mtrid2.temanikm.ui.MainActivity2
import com.mtrid2.temanikm.R

class MainActivity : AppCompatActivity() {
    lateinit var sharedPreferences: SharedPreferences

    private lateinit var edtUsername: EditText
    private lateinit var edtPassword: EditText
    //private lateinit var btnLogin: ImageView
    //private lateinit var tvSignup: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtUsername = findViewById(R.id.edt_username)
        edtPassword = findViewById(R.id.edt_password)
        //btnLogin = findViewById(R.id.arrow)
        //tvSignup = findViewById(R.id.tv_signup)

        sharedPreferences = getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
    }

    fun onClick (v: View) {
        when (v.id) {
            R.id.arrow -> {
                val inputUsername = edtUsername.text.toString().trim()
                val inputPass = edtPassword.text.toString().trim()

                var isEmptyFields = false

                if (inputUsername.isEmpty()) {
                    isEmptyFields = true
                    edtUsername.error = "Field ini tidak boleh kosong"
                }
                if (inputPass.isEmpty()) {
                    isEmptyFields = true
                    edtPassword.error = "Field ini tidak boleh kosong"
                }

                if (!isEmptyFields) {
                    //TODO: CEK DATA EMAIL DAN PASSWORD, KALAU ADA YANG COCOK: match = true
                    val match = true
                    if (match) {
                        //TODO : CEK ROLE USER, MASUKIN VARIABEL user
                        val user = "Manager"

                        val editor: SharedPreferences.Editor = sharedPreferences.edit()
                        editor.putString("USER", user)
                        editor.apply()

                        val moveIntent = Intent(this@MainActivity, MainActivity2::class.java)
                        startActivity(moveIntent)
                        finish()
                    } else {
                        Toast.makeText(this, "Email atau Password Salah", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            R.id.tv_signup -> {
                val moveIntent = Intent(this@MainActivity, RegisterActivity::class.java)
                startActivity(moveIntent)
            }
        }
    }
}

