package com.mtrid2.temanikm.ui.shipment

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.mtrid2.temanikm.databinding.ItemRowBinding

class ShipmentAdapter: RecyclerView.Adapter<ShipmentAdapter.ShipmentViewHolder>() {
    var listShipments = ArrayList<Shipment>()

    fun setShipment(shipments: List<Shipment>?) {
        if (shipments == null) return
        this.listShipments.clear()
        this.listShipments.addAll(shipments)
    }

    fun addItem(shipment: Shipment) {
        this.listShipments.add(shipment)
        notifyItemInserted(this.listShipments.size - 1)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShipmentViewHolder {
        val binding = ItemRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ShipmentViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ShipmentViewHolder, position: Int) {
        holder.bind(listShipments[position])
    }

    override fun getItemCount(): Int = this.listShipments.size

    inner class ShipmentViewHolder(private val binding: ItemRowBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(shipment: Shipment) {
            binding.tvItemStatus.text = shipment.detail.toString()
            binding.tvOrderType.text = "Orde ID : ${shipment.orderID}"
            binding.tvDescription.text = "Shipment Date : ${shipment.shipmentDate}"
            binding.tvDeadline.text = "Finish Date : ${shipment.finishDate}"
        }
    }
} 