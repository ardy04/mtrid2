package com.mtrid2.temanikm.ui.addOrder

import android.app.DatePickerDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AlertDialog
import com.mtrid2.temanikm.ui.MainActivity2
import com.mtrid2.temanikm.R
import com.mtrid2.temanikm.databinding.ActivityAddUpdateItemBinding
import com.mtrid2.temanikm.ui.OrderInfo
import java.text.SimpleDateFormat
import java.util.*

class AddUpdateItemActivity : AppCompatActivity(), View.OnClickListener, AdapterView.OnItemSelectedListener {
    private var spinner: Spinner? = null
    private var typeSpinner: Spinner? = null
    private var arrayAdapter: ArrayAdapter<String>? = null

    private var order: OrderInfo? = null
    private var divan: String = ""
    private var type: String = ""
    private var date: String = ""

    //detail divan list
    private var divanList = arrayOf(
            "Biasa",
            "Laci",
            "Permata"
    )

    //type order list
    private var typeList = arrayOf(
            "Type1",
            "Type2",
            "Type3",
            "Type4"
    )


    private lateinit var binding: ActivityAddUpdateItemBinding

    companion object {
        const val ALERT_DIALOG_CLOSE = 10
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddUpdateItemBinding.inflate(layoutInflater)
        setContentView(binding.root)

        spinner = findViewById(R.id.spinners)
        arrayAdapter = ArrayAdapter(applicationContext, R.layout.spinner_item, divanList)
        spinner?.adapter = arrayAdapter
        spinner?.setSelection(0)
        spinner?.onItemSelectedListener = this

        typeSpinner = findViewById(R.id.type_spinners)
        arrayAdapter = ArrayAdapter(applicationContext, R.layout.spinner_item, typeList)
        typeSpinner?.adapter = arrayAdapter
        typeSpinner?.setSelection(0)
        typeSpinner?.onItemSelectedListener = this

        //calendar
        val c = Calendar.getInstance()
        val year = c.get(Calendar.YEAR)
        val month = c.get(Calendar.MONTH)
        val day = c.get(Calendar.DAY_OF_MONTH)

        binding.btnDatepicker.setOnClickListener {
            val dpd = DatePickerDialog(this, DatePickerDialog.OnDateSetListener { view, year, month, dayOfMonth ->
                val montH = month + 1
                date = "$dayOfMonth/$montH/$year"
                binding.txtDeadline.text = date
            }, year, month, day)
            dpd.show()
        }

        supportActionBar?.title = "Tambah"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            android.R.id.home -> showAlertDialog(ALERT_DIALOG_CLOSE)
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onBackPressed() {
        showAlertDialog(ALERT_DIALOG_CLOSE)
    }

    override fun onClick(v: View?) {
        if (v?.id == R.id.btn_submit) {
            val detailDivan = divan.trim()
            val orderType = type.trim()
            val color = binding.edtColor.text.toString().trim()
            val deadline = date
            val size = binding.edtSize.text.toString().trim()

            val sdf = SimpleDateFormat("dd/MM/yyyy")
            val date = sdf.format(Calendar.getInstance().time)

            if (size.isEmpty()) {
                binding.edtSize.error = "Field can not be blank"
                return
            }
            if (color.isEmpty()) {
                binding.edtColor.error = "Field can not be blank"
                return
            }


            order?.detailDivan = detailDivan
            order?.orderType = orderType
            //order?.deadline = deadline
            order?.color = color
            order?.orderDate = date
            order?.size = size.toInt()
            //order?.status = "BELUM"

            //TODO : KIRIM DATA ORDER

            val moveIntent = Intent(this@AddUpdateItemActivity, MainActivity2::class.java)
            startActivity(moveIntent)
            finish()
        }
    }

    override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
        type = typeSpinner?.selectedItem as String
        divan = spinner?.selectedItem as String
    }

    override fun onNothingSelected(parent: AdapterView<*>?) {
    }

    private fun showAlertDialog(type: Int) {
        val dialogTitle = "Batal"
        val dialogMessage = "Apakah anda ingin membatalkan perubahan pada form?"

        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle(dialogTitle)
        alertDialogBuilder
            .setMessage(dialogMessage)
            .setCancelable(false)
            .setPositiveButton("Ya") { _, _ -> finish() }
            .setNegativeButton("Tidak") { dialog, _ -> dialog.cancel() }
        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }
}