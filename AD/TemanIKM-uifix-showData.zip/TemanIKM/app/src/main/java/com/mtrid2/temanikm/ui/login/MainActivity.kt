@file:Suppress("DEPRECATION")

package com.mtrid2.temanikm.ui.login

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.Toast
import com.mtrid2.temanikm.ui.MainActivity2
import com.mtrid2.temanikm.R
import java.sql.DriverManager

class MainActivity : AppCompatActivity() {
    private var asyncTask: Async? = null

    lateinit var sharedPreferences: SharedPreferences

    private lateinit var edtUsername: EditText
    private lateinit var edtPassword: EditText
    //private lateinit var btnLogin: ImageView
    //private lateinit var tvSignup: TextView

    private var user: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        edtUsername = findViewById(R.id.edt_username)
        edtPassword = findViewById(R.id.edt_password)
        //btnLogin = findViewById(R.id.arrow)
        //tvSignup = findViewById(R.id.tv_signup)

        sharedPreferences = getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
    }

    fun onClick (v: View) {
        when (v.id) {
            R.id.arrow -> {
                val inputUsername = edtUsername.text.toString().trim()
                val inputPass = edtPassword.text.toString().trim()

                var isEmptyFields = false

                if (inputUsername.isEmpty()) {
                    isEmptyFields = true
                    edtUsername.error = "Field ini tidak boleh kosong"
                }
                if (inputPass.isEmpty()) {
                    isEmptyFields = true
                    edtPassword.error = "Field ini tidak boleh kosong"
                }

                if (!isEmptyFields) {
                    asyncTask = Async()
                    asyncTask!!.execute()

                    Log.d("user", user)
                    //TODO: CEK DATA EMAIL DAN PASSWORD, KALAU ADA YANG COCOK
                    if (!user.equals("")) {
                        //TODO : CEK ROLE USER, MASUKIN VARIABEL user

                        val editor: SharedPreferences.Editor = sharedPreferences.edit()
                        editor.putString("USER", user)
                        editor.apply()

                        val moveIntent = Intent(this@MainActivity, MainActivity2::class.java)
                        startActivity(moveIntent)
                        finish()
                    } else {
                        Toast.makeText(this, "Email atau Password Salah", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            R.id.tv_signup -> {
                val moveIntent = Intent(this@MainActivity, RegisterActivity::class.java)
                startActivity(moveIntent)
            }
        }
    }

    inner class Async: AsyncTask<Void, Void, Void>() {

        var records: String = ""
        var errors: String = ""

        override fun doInBackground(vararg params: Void?): Void? {
            try {
                Class.forName("com.mysql.jdbc.Driver")
                val connection = DriverManager.getConnection(
                        "jdbc:mysql://34.101.233.26/db_raw",
                        "root",
                        "intense-agency-314911"
                )
                val statement = connection.createStatement()
                val resultSet = statement.executeQuery("SELECT * FROM login WHERE email='ali_uzumaki@gmal.com' AND password='8rpbz11t'")

                while (resultSet.next()) {
                    records += resultSet.getString(5)
                }
            } catch (e: Exception) {
                errors = e.toString()
            }

            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            user = records
            if (errors !== "") {
                Log.d("error", errors)
            }
            super.onPostExecute(aVoid)
        }
    }
}

