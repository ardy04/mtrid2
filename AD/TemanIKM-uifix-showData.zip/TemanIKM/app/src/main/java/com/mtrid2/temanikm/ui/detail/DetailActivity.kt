package com.mtrid2.temanikm.ui.detail

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.mtrid2.temanikm.R
import com.mtrid2.temanikm.databinding.ActivityDetailBinding
import com.mtrid2.temanikm.ui.OrderInfo

class DetailActivity : AppCompatActivity() {
    private var order: OrderInfo? = null
    private var id: String? = ""

    lateinit var preferences: SharedPreferences

    private lateinit var binding: ActivityDetailBinding

    companion object {
        const val EXTRA_ORDER = "extra_order"
        const val EXTRA_ID = "extra_position"
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        order = intent.getParcelableExtra(EXTRA_ORDER)
        id = intent.getStringExtra(EXTRA_ID)

        //TAMPILKAN DATA DETAIL ORDER
        binding.txtOrderId.text = order?.id
        binding.orderType.text = order?.orderType
        binding.status.text = (order?.price).toString()
        binding.divan.text = order?.detailDivan
        binding.size.text = (order?.size).toString()
        binding.color.text = order?.color
        binding.deadline.text = order?.finishDate
        binding.orderDate.text = order?.orderDate

        supportActionBar?.title = "Detail Order Information"
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        preferences = getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)

        val user = preferences.getString("USER", "")
        if (user!! == "manager"){
            binding.btnFinish.visibility = View.GONE
        } else {
            binding.btnFinish.visibility = View.VISIBLE
        }
    }

    fun onClick(v: View){
        if (v.id == R.id.btn_finish) {
            binding.status.text = "FINISH"
            //order?.status = "FINISH"

            //TODO : KIRIM DATA STATUS ORDER FINISH
        }
    }
}