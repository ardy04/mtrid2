package com.mtrid2.temanikm.ui.login

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import com.mtrid2.temanikm.R

class RegisterActivity : AppCompatActivity() {
    private lateinit var edtName: EditText
    private lateinit var edtUsername: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnSignup: ImageView
    private lateinit var tvLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        edtName = findViewById(R.id.edt_name)
        edtUsername = findViewById(R.id.edt_username)
        edtPassword = findViewById(R.id.edt_password)
        btnSignup = findViewById(R.id.arrow)
        tvLogin = findViewById(R.id.tv_login)
    }

    fun onClick (v: View) {
        when (v.id) {

            R.id.arrow -> {
                val inputName = edtName.text.toString().trim()
                val inputUsername = edtUsername.text.toString().trim()
                val inputPass = edtPassword.text.toString().trim()

                var isEmptyFields = false

                if (inputName.isEmpty()) {
                    isEmptyFields = true
                    edtName.error = "Field ini tidak boleh kosong"
                }
                if (inputUsername.isEmpty()) {
                    isEmptyFields = true
                    edtUsername.error = "Field ini tidak boleh kosong"
                }
                if (inputPass.isEmpty()) {
                    isEmptyFields = true
                    edtPassword.error = "Field ini tidak boleh kosong"
                }

                if (!isEmptyFields) {
                    //insert db
                    val moveWithDataIntent = Intent(this@RegisterActivity, MainActivity::class.java)
                    startActivity(moveWithDataIntent)
                }
            }

            R.id.tv_login -> {
                val moveIntent = Intent(this@RegisterActivity, MainActivity::class.java)
                startActivity(moveIntent)
            }
        }
    }
}