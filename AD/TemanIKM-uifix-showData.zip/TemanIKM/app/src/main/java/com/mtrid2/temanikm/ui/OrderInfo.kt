package com.mtrid2.temanikm.ui

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class OrderInfo (
    var id: String = "",
    var detailDivan: String? = null,
    var orderType: String? = null,
    var size: Int? = null,
    var color: String? = null,
    var orderDate: String? = null,
    var finishDate: String? = null,
    var price: Int? = null
) :Parcelable