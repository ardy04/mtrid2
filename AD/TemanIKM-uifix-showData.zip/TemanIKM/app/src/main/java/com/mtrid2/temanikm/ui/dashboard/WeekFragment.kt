@file:Suppress("DEPRECATION")

package com.mtrid2.temanikm.ui.dashboard

import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet
import com.mtrid2.temanikm.R
import com.mtrid2.temanikm.databinding.FragmentWeekBinding

class WeekFragment : Fragment() {
    private lateinit var binding: FragmentWeekBinding

    override fun onCreateView(
            inflater: LayoutInflater, container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentWeekBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.txtChart1.text = "Grafik Produksi"
        setLineChartData()

        binding.txtChart2.text = "Persentase Produksi"
        setPieChartData()
    }

    fun setLineChartData() {

        //TODO: AMBIL DATA ORDER DATE YANG MAU DITAMPILKAN
        val xvalue = ArrayList<String>()
        xvalue.add("Minggu 1") // bisa di add gini atau langsung set arrayList nya
        xvalue.add("Minggu 2")
        xvalue.add("Minggu 3")
        xvalue.add("Minggu 4")

        //TODO: AMBIL DATA BANYAK ORDER TYPE1
        val type1 = ArrayList<Float>()
        type1.add(20f)
        type1.add(30f)
        type1.add(10f)
        type1.add(40f)

        val lineEntry = ArrayList<Entry>()

        for ((i, item) in type1.withIndex()){
            lineEntry.add(Entry(item, i))
        }

        //TODO: AMBIL DATA BANYAK ORDER TYPE2
        val type2 = ArrayList<Float>()
        type2.add(10f)
        type2.add(20f)
        type2.add(60f)
        type2.add(30f)

        val lineEntry1 = ArrayList<Entry>()

        for ((i, item) in type2.withIndex()){
            lineEntry1.add(Entry(item, i))
        }

        //TODO: AMBIL DATA BANYAK ORDER TYPE3
        val type3 = ArrayList<Float>()
        type3.add(5f)
        type3.add(10f)
        type3.add(20f)
        type3.add(30f)

        val lineEntry2 = ArrayList<Entry>()

        for ((i, item) in type3.withIndex()){
            lineEntry2.add(Entry(item, i))
        }

        //TODO: AMBIL DATA BANYAK ORDER TYPE4
        val type4 = ArrayList<Float>()
        type4.add(50f)
        type4.add(10f)
        type4.add(15f)
        type4.add(20f)

        val lineEntry3 = ArrayList<Entry>()

        for ((i, item) in type4.withIndex()){
            lineEntry3.add(Entry(item, i))
        }

        val lineDataset = LineDataSet(lineEntry, "Type 1")
        lineDataset.color = resources.getColor(R.color.prime)
        lineDataset.circleRadius = 0f

        val lineDataset1 = LineDataSet(lineEntry1, "Type 2")
        lineDataset1.color = resources.getColor(R.color.purple_500)
        lineDataset1.circleRadius = 0f

        val lineDataset2 = LineDataSet(lineEntry2, "Type 3")
        lineDataset2.color = resources.getColor(R.color.teal_200)
        lineDataset2.circleRadius = 0f

        val lineDataset3 = LineDataSet(lineEntry3, "Type 4")
        lineDataset3.color = resources.getColor(R.color.orange)
        lineDataset3.circleRadius = 0f

        val finalDataset = ArrayList<LineDataSet>()
        finalDataset.add(lineDataset)
        finalDataset.add(lineDataset1)
        finalDataset.add(lineDataset2)
        finalDataset.add(lineDataset3)

        val data = LineData(xvalue, finalDataset as List<ILineDataSet>?)

        binding.lineChart.data = data
        binding.lineChart.setBackgroundColor(resources.getColor(R.color.white))
        binding.lineChart.animateXY(3000,3000)
    }

    fun setPieChartData(){
        val xvalues = ArrayList<String>()
        xvalues.add("Type 1")
        xvalues.add("Type 2")
        xvalues.add("Type 3")
        xvalues.add("Type 4")

        //TODO: AMBIL DATA BANYAK ORDER TYPE1, TYPE 2, TYPE 3
        val type = ArrayList<Float>()
        type.add(50f) // TYPE 1
        type.add(10f) // TYPE 2
        type.add(15f) // TYPE 3
        type.add(20f) // TYPE 4

        val pieChartEntry = ArrayList<Entry>()

        for ((i, item) in type.withIndex()){
            pieChartEntry.add(Entry(item, i))
        }

        val colors = ArrayList<Int>()
        colors.add(Color.CYAN)
        colors.add(Color.GREEN)
        colors.add(Color.YELLOW)
        colors.add(Color.MAGENTA)

        val pieDataset = PieDataSet(pieChartEntry, "Order")
        pieDataset.colors = colors
        pieDataset.sliceSpace = 5f

        val data = PieData(xvalues, pieDataset)
        binding.pieChart.data = data
        binding.pieChart.holeRadius = 15f
        binding.pieChart.setBackgroundColor(resources.getColor(R.color.white))
        binding.pieChart.animateY(3000)
        binding.pieChart.setDescription("Pie Chart Order")

        val legend: Legend = binding.pieChart.legend
        legend.position = Legend.LegendPosition.RIGHT_OF_CHART_CENTER
    }
}