@file:Suppress("DEPRECATION")

package com.mtrid2.temanikm.ui.home

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.AsyncTask
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.mtrid2.temanikm.ui.addOrder.AddUpdateItemActivity
import com.mtrid2.temanikm.databinding.ActivityOrderInfoBinding
import com.mtrid2.temanikm.ui.OrderInfo
import java.sql.DriverManager

class HomeFragment : Fragment() {

    private var asyncTask: Async? = null

    lateinit var preferences: SharedPreferences

    private lateinit var binding: ActivityOrderInfoBinding

    private lateinit var homeViewModel: HomeViewModel

    private var data = ArrayList<OrderInfo>()
    private var orderAdapter = OrderAdapter()

    override fun onCreateView(
            inflater: LayoutInflater,
            container: ViewGroup?,
            savedInstanceState: Bundle?
    ): View? {
        binding = ActivityOrderInfoBinding.inflate(layoutInflater, container, false)

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        if (activity != null) {
            (requireActivity() as AppCompatActivity).supportActionBar?.title = "Order Information"
            //homeViewModel = ViewModelProvider(this).get(HomeViewModel::class.java)


            asyncTask = Async()
            asyncTask!!.execute()
            //TODO: TAMPILKAN DATA ORDER


            binding.progressbar.visibility = View.GONE

            preferences = this.activity?.getSharedPreferences("SHARED_PREF", Context.MODE_PRIVATE)
                    ?: return

            val user = preferences.getString("USER", "")
            Log.d("user", user!!)

            if (user!!.equals("manager")) {
                binding.fabAdd.visibility = View.VISIBLE
                binding.fabAdd.setOnClickListener {
                    val intent = Intent(activity, AddUpdateItemActivity::class.java)
                    startActivity(intent)
                }
            } else {
                binding.fabAdd.visibility = View.GONE
            }
        }
    }

    inner class Async: AsyncTask<Void, Void, Void>() {

        var errors = ""
        var order = OrderInfo()

        override fun doInBackground(vararg params: Void?): Void? {
            try {
                Class.forName("com.mysql.jdbc.Driver")
                val connection = DriverManager.getConnection(
                    "jdbc:mysql://34.101.233.26/db_raw",
                    "root",
                    "intense-agency-314911"
                )
                val statement = connection.createStatement()
                val resultSet = statement.executeQuery("SELECT * FROM raw")

                while (resultSet.next()) {
                    order = OrderInfo(
                        resultSet.getString(1).toString(),
                        resultSet.getString(5),
                        resultSet.getString(4),
                        resultSet.getInt(2),
                        resultSet.getString(3),
                        resultSet.getString(7),
                        resultSet.getString(8),
                        resultSet.getInt(11)
                    )
                    data.add(order)
                }
            } catch (e: Exception) {
                errors = e.toString()
            }

            return null
        }

        override fun onPostExecute(aVoid: Void?) {
            orderAdapter.setOrder(data)

            binding.rvOrders.layoutManager = LinearLayoutManager(context)
            binding.rvOrders.setHasFixedSize(true)
            binding.rvOrders.adapter = orderAdapter
            if (errors !== "") {
                Log.d("error", errors)
            }
            super.onPostExecute(aVoid)
        }
    }
}